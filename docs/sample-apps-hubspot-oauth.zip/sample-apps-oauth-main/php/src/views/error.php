<?php include __DIR__.'/_partials/header.php'; ?>

<h3 class="error"><?php echo htmlentities($message); ?></h3>

<?php include __DIR__.'/_partials/footer.php'; ?>
