<?php

return [
    '/oauth/login',
    '/oauth/authorize',
    '/oauth/callback',
];
