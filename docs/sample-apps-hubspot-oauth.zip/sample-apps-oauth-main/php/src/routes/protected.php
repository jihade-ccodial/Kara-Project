<?php

return [
    '/contacts/list',
];
