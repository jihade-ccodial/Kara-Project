Hubspot.configure do |config|
  config.params_encoding = :multi
end